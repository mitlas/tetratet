<?
 header("Location: ../");
?>