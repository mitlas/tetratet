
/*
 arteffect inTetris 1.2

 The script is the Tetris/Pentix/whatever game engine
 which uses its own plug-ins system for visualization.

 Copyright (c) Dmitry Popov, 06/2010
*/




 // ---- configuration variables

 var figureBlockSize = 25; // elemental block size (in pixels)
 var figureBlockFillStyle = 'white url(\'img/brick.png\') no-repeat;'; // blocks background rules

 var hilitedBlockFillStyle = 'lightyellow'; // hilited blocks background rules

 var glassWidth = 15; // in blocks, see figureBlockSize
 var glassHeight = 25; // in blocks, see figureBlockSize
 var glassFillStyle = 'rgb(255,255,255)'; // glass background rules

 var gameTickSpeed = 500; // milliseconds between automatic movements the figure one block down
 var gameElapsedTimeUpdateSpeed = 1000; // milliseconds between updates of elapsed time of the game

 var outputMode = 'table'; // output mode: 'table' - via HTML-table, 'canvas' - via HTML5 canvas element




 // ---- figures variables

 var figures; // set of current figures collection


 var figures_tetris = new Array(); // tetris

 figures_tetris[0] = new Array();
 figures_tetris[0][0] = [1];
 figures_tetris[0][1] = [1];
 figures_tetris[0][2] = [1];
 figures_tetris[0][3] = [1];

 figures_tetris[1] = new Array();
 figures_tetris[1][0] = [1, 0];
 figures_tetris[1][1] = [1, 0];
 figures_tetris[1][2] = [1, 1];

 figures_tetris[2] = new Array();
 figures_tetris[2][0] = [1, 1];
 figures_tetris[2][1] = [1, 1];

 figures_tetris[3] = new Array();
 figures_tetris[3][0] = [1, 0];
 figures_tetris[3][1] = [1, 1];
 figures_tetris[3][2] = [1, 0];

 figures_tetris[4] = new Array();
 figures_tetris[4][0] = [1, 0];
 figures_tetris[4][1] = [1, 1];
 figures_tetris[4][2] = [0, 1];


 var figures_pentix = new Array(); // pentix

 figures_pentix[0] = new Array();
 figures_pentix[0][0] = [1];
 figures_pentix[0][1] = [1];
 figures_pentix[0][2] = [1];
 figures_pentix[0][3] = [1];
 figures_pentix[0][4] = [1];

 figures_pentix[1] = new Array();
 figures_pentix[1][0] = [1, 0];
 figures_pentix[1][1] = [1, 0];
 figures_pentix[1][2] = [1, 0];
 figures_pentix[1][3] = [1, 1];

 figures_pentix[2] = new Array();
 figures_pentix[2][0] = [1, 0];
 figures_pentix[2][1] = [1, 0];
 figures_pentix[2][2] = [1, 1];
 figures_pentix[2][3] = [1, 0];

 figures_pentix[3] = new Array();
 figures_pentix[3][0] = [0, 1, 0];
 figures_pentix[3][1] = [1, 1, 1];
 figures_pentix[3][2] = [0, 1, 0];

 figures_pentix[4] = new Array();
 figures_pentix[4][0] = [0, 1, 0];
 figures_pentix[4][1] = [0, 1, 1];
 figures_pentix[4][2] = [1, 1, 0];

 figures_pentix[5] = new Array();
 figures_pentix[5][0] = [0, 1, 0];
 figures_pentix[5][1] = [0, 1, 0];
 figures_pentix[5][2] = [1, 1, 1];

 figures_pentix[6] = new Array();
 figures_pentix[6][0] = [0, 1, 1];
 figures_pentix[6][1] = [1, 1, 0];
 figures_pentix[6][2] = [1, 0, 0];

 figures_pentix[7] = new Array();
 figures_pentix[7][0] = [1, 1, 1];
 figures_pentix[7][1] = [1, 0, 0];
 figures_pentix[7][2] = [1, 0, 0];

 figures_pentix[8] = new Array();
 figures_pentix[8][0] = [0, 1];
 figures_pentix[8][1] = [1, 1];
 figures_pentix[8][2] = [1, 1];

 figures_pentix[9] = new Array();
 figures_pentix[9][0] = [0, 1, 1];
 figures_pentix[9][1] = [0, 1, 0];
 figures_pentix[9][2] = [1, 1, 0];

 figures_pentix[10] = new Array();
 figures_pentix[10][0] = [1, 1];
 figures_pentix[10][1] = [0, 1];
 figures_pentix[10][2] = [1, 1];

 figures_pentix[11] = new Array();
 figures_pentix[11][0] = [0, 1];
 figures_pentix[11][1] = [0, 1];
 figures_pentix[11][2] = [1, 1];
 figures_pentix[11][3] = [1, 0];

 figures = figures_pentix; // let's stay with pentix by default




 // ---- global runtime variables

 var glass; // glass that contain all the blocks

 var figure; // current figure
 var currentX; // its current x-axis position
 var currentY; // its current y-axis position

 var nextFigure; // next figure

 var prizeImgNum = 177;

 var maxFigureSize = 0; // maximal size of figure (in blocks) to draw next figure area
 for (i = 0; i < figures.length; ++i)
 {
  maxFigureSize = ((maxFigureSize > figures[i].length) ? maxFigureSize: figures[i].length);

  for (j = 0; j < figures[i].length; ++j)
   maxFigureSize = ((maxFigureSize > figures[i][j].length) ? maxFigureSize : figures[i][j].length);
 }

 var numLinesComplete = 0; // current number of complete lines
 var numTimeComplete = 0; // current number of passed milliseconds

 var gametickInterval = false; // id of the main game's cycle that moves the figure down
 var gametimeInterval = false; // id of the time's cycle that show how long is the game




 // ---- glass functions

 function glassInit() // empty & redraw glass
 {
  numTimeComplete = 0;
  numLinesComplete = document.getElementById('numlines').innerHTML = 0;

  glass = new Array(glassWidth);

  for (i = 0; i < glassWidth; ++i)
   glass[i] = new Array(glassHeight);

  for (i = 0; i < glassWidth; ++i)
   for (j = 0; j < glassHeight; ++j)
    if (j > (glassHeight / 4 * 3))
     glass[i][j] = ((Math.random() > 0.5) ? 1 : 0);
    else
     glass[i][j] = 0;

  glassDraw();
 }

 function glassCreate() // create glass
 {
  return ((outputMode == 'table') ? table_glassCreate() : canvas_glassCreate());
 }

 function glassDraw() // draw glass
 {
  return ((outputMode == 'table') ? table_glassDraw() : canvas_glassDraw());
 }

 function glassErase() // erase glass
 {
  return ((outputMode == 'table') ? table_glassErase() : canvas_glassErase());
 }

 function nextfigureCreate() // create next figure area
 {
  return ((outputMode == 'table') ? table_nextfigureCreate() : canvas_nextfigureCreate());
 }

 function nextfigureDraw() // draw next figure in its area
 {
  return ((outputMode == 'table') ? table_nextfigureDraw() : canvas_nextfigureDraw());
 }




 // canvas glass functions (as plug-in)

 function canvas_glassCreate() // create CANVAS element for the glass visualization
 {
  document.write('<CANVAS ID="glass" STYLE="border:1px dashed #999; padding:2px;">����������, ���������� ��������� ������ ������ ��������!</CANVAS>\n');
 }



 function canvas_glassDraw() // draw canvas glass
 {
  canvas_glassErase();

  var canvas = document.getElementById('glass');

  if (canvas.getContext)
  {
   var ctx = canvas.getContext('2d');

   ctx.fillStyle = figureBlockFillStyle;

   for (i = 0; i < glass.length; ++i)
    for (j = 0; j < glass[0].length; ++j)
     if (glass[i][j] > 0)
      ctx.fillRect(i * figureBlockSize, j * figureBlockSize, figureBlockSize, figureBlockSize);

   ctx.fillStyle = hilitedBlockFillStyle;

   if (figure != undefined)
    for (i = currentX; i < currentX + figure.length; ++i)
     for (j = 0; j < glass[0].length; ++j)
      if (glass[i][j] == 0)
       ctx.fillRect(i * figureBlockSize, j * figureBlockSize, figureBlockSize, figureBlockSize);

   return true;
  }

  return false;
 }



 function canvas_glassErase() // erase glass
 {
  var canvas = document.getElementById('glass');

  if (canvas.getContext)
  {
   var ctx = canvas.getContext('2d');

   ctx.fillStyle = glassFillStyle;
   ctx.fillRect(0, 0, glassWidth * figureBlockSize, glassHeight * figureBlockSize);

   return true;
  }

  return false;
 }



 function canvas_nextfigureCreate() // create CANVAS element for the next figure visualization
 {
  document.write('<CANVAS ID="nextFigure" STYLE="border:1px dashed #999; padding:2px;"></CANVAS>\n');
 }



 function canvas_nextfigureDraw() // draw next figure in its area
 {
  var canvas = document.getElementById('nextFigure');

  if (canvas.getContext)
  {
   var ctx = canvas.getContext('2d');

   ctx.fillStyle = "rgb(255,255,255)";
   ctx.fillRect(0, 0, maxFigureSize * figureBlockSize, maxFigureSize * figureBlockSize);

   ctx.fillStyle = "rgb(0,200,0)";

   var x = Math.round((maxFigureSize * figureBlockSize - nextFigure.length * figureBlockSize) / 2);
   var y = Math.round((maxFigureSize * figureBlockSize - nextFigure[0].length * figureBlockSize) / 2);

   for (i = 0; i < nextFigure.length; ++i)
    for (j = 0; j < nextFigure[0].length; ++j)
     if (nextFigure[i][j] > 0)
      ctx.fillRect(x + i * figureBlockSize, y + j * figureBlockSize, figureBlockSize, figureBlockSize);

   return true;
  }

  return false;
 }




 // table glass functions (as plug-in)

 function table_glassCreate() // create HTML table for the glass visualization
 {
  with (document)
  {
   write('<STYLE MEDIA="all" type="text/css">' +
    '.emptyBlock { background: ' + glassFillStyle + '; }' +
    '.filledBlock { background: ' + figureBlockFillStyle + '; }' +
    '.hilitedBlock { background: ' + hilitedBlockFillStyle + '; }' +
    '</STYLE>');

   write('<TABLE WIDTH="' + (glassWidth * figureBlockSize) + '" HEIGHT="' + (glassHeight * figureBlockSize) +
    '" ID="glass" ALIGN=CENTER BORDER=0 CELLPADDING=0 CELLSPACING=0 STYLE="border:1px dashed #999; padding:2px;"> \n');

   for (j = 0; j < glassHeight; ++j)
   {
    write('<TR>\n');

    for (i = 0; i < glassWidth; ++i)
     write('<TD WIDTH="' + figureBlockSize + '" HEIGHT="' + figureBlockSize +
      '"ID="glassBlock-' + i + '-' + j + '">&nbsp;</TD>\n');

    write('</TR>\n');
   }

   write('</TABLE>\n');
  }
 }



 function table_glassDraw() // draw glass visualised as a HTML-table
 {
  table_glassErase();

  var canvas = document.getElementById('glass');

  if (canvas != undefined)
  {
   for (i = 0; i < glass.length; ++i)
    for (j = 0; j < glass[0].length; ++j)
     if (glass[i][j] > 0)
      document.getElementById('glassBlock-' + i + '-' + j).className = 'filledBlock';

   if (figure != undefined)
    for (i = currentX; i < currentX + figure.length; ++i)
     for (j = 0; j < glass[0].length; ++j)
      if (glass[i][j] == 0)
       document.getElementById('glassBlock-' + i + '-' + j).className = 'hilitedBlock';

   return true;
  }

  return false;
 }



 function table_glassErase() // erase glass visualised as a HTML-table
 {
  var canvas = document.getElementById('glass');

  if (canvas != undefined)
  {
   for (i = 0; i < glass.length; ++i)
    for (j = 0; j < glass[0].length; ++j)
     document.getElementById('glassBlock-' + i + '-' + j).className = 'emptyBlock';

   return true;
  }

  return false;
 }



 function table_nextfigureCreate() // create TABLE element for the next figure visualization
 {
  with (document)
  {
   write('<TABLE ID="nextFigure" WIDTH="' + (maxFigureSize * figureBlockSize) + '" HEIGHT="' + (maxFigureSize * figureBlockSize) +
    '" ALIGN=CENTER BORDER=0 CELLPADDING=0 CELLSPACING=0 STYLE="border:1px dashed #999; padding:2px;"> \n');

   write('<TR><TD ID="nextFigureCell" ALIGN=CENTER VALIGN=MIDDLE WIDTH="' +
    (maxFigureSize * figureBlockSize) + '" HEIGHT="' + (maxFigureSize * figureBlockSize) + '">&nbsp;</TD></TR>\n');

   write('</TABLE>\n');
  }
 }



 function table_nextfigureDraw() // draw next figure in its area
 {
  var canvas = document.getElementById('nextFigure');

  if (canvas != undefined)
  {
   var data = '';

   data += '<TABLE WIDTH="' + (nextFigure.length * (figureBlockSize - 1)) + '" HEIGHT="' + (nextFigure[0].length * (figureBlockSize - 1)) +
    '" BORDER=0 CELLPADDING=0 CELLSPACING=0> \n';

   for (x = 0; x < nextFigure[0].length; ++x)
   {
    data += '<TR>\n';

    for (y = 0; y < nextFigure.length; ++y)
     data += '<TD WIDTH="' + (figureBlockSize - 1) + '" HEIGHT="' + (figureBlockSize - 1) + '" CLASS="' +
      ((nextFigure[y][x] > 0) ? 'filledBlock' : 'emptyBlock') + '">&nbsp;</TD>\n';

    data += '</TR>\n';
   }

   data += '</TABLE>\n';

   document.getElementById('nextFigureCell').innerHTML = data;

   return true;
  }

  return false;
 }








 // ---- figure functions

 function figureGetRandom() // retruns random figure from current figures array
 {
  if (figures != undefined)
  {
   figureId = Math.floor(Math.random() * (figures.length + 1)) - 1;

   if (figures[figureId] == undefined)
    return figures[0];
   else
    return figures[figureId];
  }
  else
   return null;
 }



 function figureNew() // create new figure or finish the game
 {
  // delete complete lines from the glass
  var completeLines = new Array(glassHeight);
  var isPrizePicUpdated = false;

  for (i = 0; i < completeLines.length; ++i)
   completeLines[i] = 1;

  for (i = 0; i < glass.length; ++i)
   for (j = 0; j < glass[0].length; ++j)
    if (glass[i][j] == 0)
     completeLines[j] = 0;

  for (i = 0; i < completeLines.length; ++i)
   if (completeLines[i] == 1)
   {
    for (j = 0; j < glass.length; ++j)
    {
     glass[j].splice(i, 1);

     var blankBlock = new Array(1);
     blankBlock[0] = 0;
     glass[j] = blankBlock.concat(glass[j]);
    }

    document.getElementById('numlines').innerHTML = ++numLinesComplete;

    /*
    if (!isPrizePicUpdated)
    {
     if (prizeImgNum == 192)
      prizeImgNum = 177;
     document.getElementById('prizeImg').src = 'http://luba-shumeiko.narod.ru/photo/' + (++prizeImgNum) + '.jpg';
     isPrizePicUpdated = true;
    }
    */

    if (numLinesComplete == 20)
    {
     clearInterval(gametickInterval);
     gametickInterval = false;

     clearInterval(gametimeInterval);
     gametimeInterval = false;

     glassDraw();

     document.getElementById('infobar').innerHTML = '<B>20 LINES COMPLETE!!!</B> press \'Enter\'...';

     return false;
    }
   }

  // create new figure
  if (nextFigure == undefined)
   figure = figureGetRandom();
  else
   figure = nextFigure;

  nextFigure = figureGetRandom();
  nextfigureDraw();

  currentX = Math.floor((glassWidth - figure.length) / 2);
  currentY = 0;

  for (i = 0; i < figure.length; ++i)
   for (j = 0; j < figure[0].length; ++j)
    if ((currentX + i >= glassWidth) || (currentY + j >= glassHeight) || (glass[currentX + i][currentY + j] == undefined) ||
     ((figure[i][j] > 0) && (glass[currentX + i][currentY + j] > 0)))
    {
     clearInterval(gametickInterval);
     gametickInterval = false;

     clearInterval(gametimeInterval);
     gametimeInterval = false;

     document.getElementById('infobar').innerHTML = 'GAME OVER, press \'Enter\'';

     return false;
    }

  figureDraw();

  /*
  if (Math.round(Math.random() * 10) > 5)
   figureRotate();

  if (Math.round(Math.random() * 10) > 5)
   figureFlipX();

  if (Math.round(Math.random() * 10) > 5)
   figureFlipY();
  */

  glassDraw();

  return true;
 }



 function figureDraw() // draw figure in memory buffer
 {
  for (i = 0; i < figure.length; ++i)
   for (j = 0; j < figure[0].length; ++j)
    if (figure[i][j] > 0)
     glass[currentX + i][currentY + j] = figure[i][j];
 }



 function figureErase() // erase figure from memory buffer
 {
  for (i = 0; i < figure.length; ++i)
   for (j = 0; j < figure[0].length; ++j)
    if (figure[i][j] > 0)
     glass[currentX + i][currentY + j] = 0;
 }



 function figureCanDrawAt(x, y) // ckeck is it possible to draw current figure in the specified location in the glass
 {
  if ((x < 0) || (y < 0) || (x + figure.length > glassWidth) || (y + figure[0].length > glassHeight))
   return false;

  for (i = 0; i < figure.length; ++i)
   for (j = 0; j < figure[0].length; ++j)
    if ((glass[x + i][y + j] == undefined) || ((figure[i][j] > 0) && (glass[x + i][y + j] > 0)))
     return false;

  return true;
 }



 function figureMove(direction) // move figure in specified direction: down, left, right
 {
  var x = currentX;
  var y = currentY;

  switch (direction)
  {
   /* can be useful for some programs based on block-moving strategy
   case 'up':
   		y = ((y > 0) ? --y : 0);
   		break;
   */
   case 'down':
   		y = ((y < (glassHeight - 1)) ? ++y : (glassHeight - 1));
   		break;
   case 'left':
   		x = ((x > 0) ? --x : 0);
   		break;
   case 'right':
   		x = ((x < (glassWidth - 1)) ? ++x : (glassWidth - 1));
   		break;
   default:
   		break;
  }

  figureErase();

  if (figureCanDrawAt(x, y))
  {
   currentX = x;
   currentY = y;
   figureDraw();
   glassDraw();

   return true;
  }
  else
  {
   figureDraw();

   if (direction == 'down') // if the figure can't move down, leave it in the glass and create new figure
    figureNew();

   return false;
  }
 }



 function figureRotate(isRotateClockwise) // rotate figure
 {
  var cacheFigure = figure;

  var newXOffset = 0; // correct figure x-position after rotation

  for (loopnum = ((isRotateClockwise) ? 0 : 2); loopnum < 3; ++loopnum) // counterclockwise (default) or clockwise
  {
   var newWidth = ((figure[0] == undefined) ? 0 : figure[0].length);
   var newHeight = figure.length;

   if ((newWidth == 0) || (newHeight == 0))
    return false;

   newXOffset += Math.ceil((figure.length - newWidth) / 2);

   var rotated = new Array(newWidth);

   for (i = 0; i < newWidth; ++i)
    rotated[i] = new Array(newHeight);

   for(i = 0; i < figure[0].length; ++i)
    for(j = 0; j < figure.length; ++j)
     rotated[i][figure.length - j - 1] = figure[j][i];

   figure = rotated;
  }

  if (figureCanDrawAt(currentX + newXOffset, currentY))
  {
   currentX += newXOffset;
   return true;
  }
  else
  {
   figure = cacheFigure;
   return false;
  }
 }



 function figureFlipX() // flip figure horizontal
 {
  var cacheFigure = figure;

  for (i = 0; i < (figure.length / 2); ++i)
  {
   tmp = figure[i];
   figure[i] = figure[figure.length - i - 1];
   figure[figure.length - i - 1] = tmp;
  }

  if (figureCanDrawAt(currentX, currentY))
   return true;
  else
  {
   figure = cacheFigure;
   return false;
  }
 }



 function figureFlipY() // flip figure vertical
 {
  var cacheFigure = figure;

  for (i = 0; i < figure.length; ++i)
   figure[i].reverse();

  if (figureCanDrawAt(currentX, currentY))
   return true;
  else
  {
   figure = cacheFigure;
   return false;
  }
 }



 function figureExchange() // exchange current figure with the next figure
 {
  var cacheFigure = figure;

  if (nextFigure == undefined)
  {
   nextFigure = figureGetRandom();
   nextfigureDraw();
  }

  figure = nextFigure;

  var newXOffset = Math.ceil((cacheFigure.length - nextFigure.length) / 2);

  if (figureCanDrawAt(currentX + newXOffset, currentY))
  {
   currentX += newXOffset;
   nextFigure = cacheFigure;
   nextfigureDraw();
   return true;
  }
  else
  {
   figure = cacheFigure;
   return false;
  }
 }







 // ---- cookie functions

 function setCookie(sName, sValue)
 {
  document.cookie = sName + '=' + escape(sValue) + ';';
 }

 function getCookie(sName)
 {
  // cookies are separated by semicolons
  var aCookie = document.cookie.split('; ');

  for (var i=0; i < aCookie.length; ++i)
  {
   // a name/value pair (a crumb) is separated by an equal sign
   var aCrumb = aCookie[i].split('=');

   if (sName == aCrumb[0])
    return unescape(aCrumb[1]);
  }

  return undefined; // a cookie with the requested name does not exist
 }








 // ---- interface functions

 function updateElapsedTime() // update a layer with text about elapsed time since the start of the current game
 {
  ++numTimeComplete;

  var mins = Math.floor(numTimeComplete / 60);
  var secs = numTimeComplete % 60;

  document.getElementById('numtime').innerHTML = ((mins > 0) ? mins : '0') + ':' + ((secs < 10) ? '0' : '') + secs;
 }



 function setFigures() // set figures collection
 {
  figures = new Array();

  var isTetris = document.forms['options'].elements['isTetris'];
  var isPentix = document.forms['options'].elements['isPentix'];

  if (!isTetris.checked && !isPentix.checked)
   isPentix.checked = true;

  if (isTetris.checked)
   figures = figures.concat(figures_tetris);

  if (isPentix.checked)
   figures = figures.concat(figures_pentix);

  if (figures.length == 0)
   figures = figures_pentix;

  isTetris.disabled = isPentix.disabled = false;

  if (isTetris.checked && !isPentix.checked)
   isTetris.disabled = true;

  if (!isTetris.checked && isPentix.checked)
   isPentix.disabled = true;

  setCookie('rtv_figures_is_tetris', ((isTetris.checked) ? '1' : '0'));
  setCookie('rtv_figures_is_pentix', ((isPentix.checked) ? '1' : '0'));
 }



 function setGameSpeed() // set figures collection
 {
  var defaultGameSpeed = 500;

  var gameSpeed = document.forms['options'].elements['gameSpeed'];

  if (gameSpeed == undefined)
   return defaultGameSpeed;
  else
  {
   var num = parseInt(gameSpeed.value);

   if (isNaN(num))
    return defaultGameSpeed;
   else
   {
    gameTickSpeed = num;
    setCookie('rtv_game_speed', num);
   }
  }

  return true;
 }



 function processKeyDown(evt) // process keyboard actions
 {
  evt = (evt) ? evt : event;

  // in pause state - react only on 'Enter', 'Esc' or 'F5' (it also prevents the figure from move/rotate/flip/exchange keyboard actions)
  if ((gametickInterval == false) && (evt.keyCode != 13) && (evt.keyCode != 27) && (evt.keyCode != 116))
   return false;

  switch (evt.keyCode)
  {
   case 13: // 'Enter' - pause
   case 27: // 'Esc' - pause
   		if (gametickInterval != false)
   		{
   		 clearInterval(gametickInterval);
   		 gametickInterval = false;

   		 clearInterval(gametimeInterval);
   		 gametimeInterval = false;

   		 document.getElementById('infobar').innerHTML = 'game paused, press \'Enter\'';
   		}
   		else
   		{
   		 if ((document.getElementById('infobar').innerHTML == 'press \'Enter\' to start!!!') ||
   		  (document.getElementById('infobar').innerHTML == 'GAME OVER, press \'Enter\'') ||
   		  (numLinesComplete == 20))
   		 {
		  glassInit();
   		  figureNew();
		 }

   		 gametickInterval = setInterval('figureMove(\'down\')', ((gameTickSpeed > 0) ? gameTickSpeed : 500));
   		 gametimeInterval = setInterval('updateElapsedTime()', ((gameElapsedTimeUpdateSpeed > 0) ? gameElapsedTimeUpdateSpeed : 1000));

   		 document.getElementById('infobar').innerHTML = 'play now!';
   		}
   		break;

   case 37: // 'Left arrow' - move figure left
   		figureMove('left');
   		break;

   case 39: // 'Right arrow' - move figure right
   		figureMove('right');
   		break;

   case 40: // 'Down arrow' - move figure down
   		figureMove('down');
   		break;

   case 38: // 'Up arrow' - rotate figure
   		figureErase();
   		figureRotate();
   		figureDraw();
   		break;

   case 32: // 'Space' - drop figure
  		figureErase();

  		var newY = currentY;
  		while (figureCanDrawAt(currentX, ++newY));
   		currentY = newY - 1;

   		figureDraw();

                figureNew();

   		break;

   case 36: // 'Home' - move figure to the left
  		figureErase();

  		var newX = currentX;
  		while (figureCanDrawAt(--newX, currentY));
   		currentX = newX + 1;

   		figureDraw();

   		break;

   case 33: // 'Page Up' - move figure to the right
   		figureErase();

   		var newX = currentX;
  		while (figureCanDrawAt(++newX, currentY));
   		currentX = newX - 1;

   		figureDraw();

   		break;

   case 35: // 'End' - move figure to the left & drop
  		figureErase();

  		var newX = currentX;
  		while (figureCanDrawAt(--newX, currentY));
   		currentX = newX + 1;

   		var newY = currentY;
  		while (figureCanDrawAt(currentX, ++newY));
   		currentY = newY - 1;

   		figureDraw();

   		figureNew();

   		break;

   case 34: // 'Page Down' - move figure to the right & drop
   		figureErase();

   		var newX = currentX;
  		while (figureCanDrawAt(++newX, currentY));
   		currentX = newX - 1;

   		var newY = currentY;
  		while (figureCanDrawAt(currentX, ++newY));
   		currentY = newY - 1;

   		figureDraw();

   		figureNew();

   		break;

   case 49: // '1' - horizontal flip
   case 112: // 'F1' - horizontal flip
   		figureErase();
   		figureFlipX();
   	        figureDraw();
	        glassDraw();
   		break;

   case 50: // '2' - next figure
   case 113: // 'F2' - next figure
   		figureErase();
   		figureExchange();
   		figureDraw();
		glassDraw();
   		break;

   case 51: // '3' - vertical flip
   case 114: // 'F3' - vertical flip
   		figureErase();
   		figureFlipY();
   		figureDraw();
		glassDraw();
   		break;

   default:
   		if (evt.keyCode == 116) // 'F5' - pass reload command to the browser
   		 return true;
   		break;
  }

  //alert(evt.keyCode);
  if (gametickInterval == false)
   return true;

  return false;
 }

 document.onkeydown = processKeyDown;



 function processOnLoad() // process onLoad event
 {
  // resize glass
  with (document.getElementById('glass'))
  {
   setAttribute('width', glassWidth * figureBlockSize);
   setAttribute('height', glassHeight * figureBlockSize);
  }


  // resize next figure area
  with (document.getElementById('nextFigure'))
  {
   setAttribute('width', maxFigureSize * figureBlockSize);
   setAttribute('height', maxFigureSize * figureBlockSize);
  }


  // set figures
  with (document.forms['options'])
  {
   elements['isTetris'].checked = elements['isPentix'].checked = false;

   if (getCookie('rtv_figures_is_tetris') == '1')
    elements['isTetris'].checked = true;

   if (getCookie('rtv_figures_is_pentix') == '1')
    elements['isPentix'].checked = true;
  }

  setFigures();


  return true;
 }




 //---- AJAX, auth & results management functions

 function loadHTML(sURL)
 {
  var request = null;

  if (typeof(XMLHttpRequest) != 'undefined')
   request = new XMLHttpRequest();
  else
  {
   var axO = ['Msxml2.XMLHTTP.6.0', 'Msxml2.XMLHTTP.4.0', 'Msxml2.XMLHTTP.3.0',
    'Msxml2.XMLHTTP', 'Microsoft.XMLHTTP'], i;

   for (i = 0; i < axO.length; i++)
   {
    try
    {
     if (request == null)
      request = new ActiveXObject(axO[i]);
     else
      break;
    }
    catch (e) {}
   }
  }

  request.open('GET', sURL, false);
  request.send(null);

  return request.responseText;
 }

 var baseURL = 'http://dev.arteffect.ru/tetris/rus/';

 function userAdd()
 {

 }

 function userLogin()
 {
  var data = '';

  data = loadHTML(baseURL + 'users/engine.php?mode=login');

  if (data.length > 0)
  {

  }
 }

 function resultSend()
 {

 }

 function resultLoad()
 {

 }

 function resultLoadAll()
 {

 }
